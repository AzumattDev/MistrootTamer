| `Version`   | `Update Notes`                                                                                                       |
|-------------|----------------------------------------------------------------------------------------------------------------------|
| 1.0.3       | Bog Witch                                                                                                            |
| 1.0.2       | Ashlands<br/>- Reduce default group size from 3 to 1 and increase default range<br/>- Update PieceManager internally |
| 1.0.0/1.0.1 | - Initial Release                                                                                                    |